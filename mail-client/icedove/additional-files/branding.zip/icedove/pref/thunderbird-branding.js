
// Default start page
pref("mailnews.start_page.url", "about:");

// start page override to load after an update
pref("mailnews.start_page.override_url", "about:");

pref("app.vendorURL", "about:");
