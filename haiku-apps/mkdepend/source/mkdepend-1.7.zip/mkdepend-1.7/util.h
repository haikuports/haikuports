/* $Id: util.h 1.1 Tue, 02 Feb 1999 17:57:55 -0700 lars $ */

/*---------------------------------------------------------------------------
 * Copyright (c) 1999 by Lars Düning. All Rights Reserved.
 * This file is free software. For terms of use see the file LICENSE.
 *---------------------------------------------------------------------------
 */

#ifndef __UTIL_H__
#define __UTIL_H__ 1

extern char * util_getpath(const char *, char **);

#endif
