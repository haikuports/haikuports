Only localization contributions are accepted at the moment, code pull requests will be rejected.

The rationale is, that I want leave the possibility to distribute GPXsee builds in the OS X/Windows
stores under a non-GPL licence open. In the future, code pull requests under a
[QT-like contribution agreement](https://d21tv0wm5mksdn.cloudfront.net/wp-content/uploads/2015/03/Qt-ContributionLicenseAgreement_v1_2_FINAL.pdf)
may become possible.
