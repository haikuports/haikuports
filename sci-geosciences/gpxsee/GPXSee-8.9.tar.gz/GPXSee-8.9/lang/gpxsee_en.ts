<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>GUI</name>
    <message numerus="yes">
        <location filename="../src/GUI/gui.cpp" line="1637"/>
        <source>%n files</source>
        <translation>
            <numerusform>%n file</numerusform>
            <numerusform>%n files</numerusform>
        </translation>
    </message>
</context>
</TS>
