#ifndef TIMETYPE_H
#define TIMETYPE_H

enum TimeType {
	Total,
	Moving
};

#endif // TIMETYPE_H
