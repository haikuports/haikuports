#ifndef FONT_H
#define FONT_H

#define FONT_FAMILY     "Arial"
#define FONT_SIZE       12 // px

#endif // FONT_H
