#ifndef CRS_H
#define CRS_H

#include "projection.h"

namespace CRS
{
	Projection projection(const QString &crs);
}

#endif // CRS_H
