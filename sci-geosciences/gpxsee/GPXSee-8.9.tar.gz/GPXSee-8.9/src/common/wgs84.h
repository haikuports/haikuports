#ifndef WGS84_H
#define WGS84_H

#define WGS84_RADIUS     6378137.0
#define WGS84_FLATTENING (1.0/298.257223563)

#endif // WGS84_H
